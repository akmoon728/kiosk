using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// PaymentPanel, ConfirmPanel, CompletePanel 데이터를 담당한다.
/// 팝업 없이 Panel 안의 텍스트/리스트만 갱신한다.
/// </summary>
public class Script3_PaymentManager : MonoBehaviour
{
    public enum PayMethod
    {
        None,
        Card,
        Point,
        ApplePay,
        SamsungPay
    }

    [Header("외부 참조")]
    public Script1_PanelManager panelManager;
    public Script2_ProductManager productManager;

    [Header("PaymentPanel")]
    public Button cardBtn;
    public Button pointBtn;
    public Button applePayBtn;
    public Button samsungPayBtn;
    public Text payAmountText;
    public Text selectedPayMethodText;
    public Text paymentGuideText;

    [Header("ConfirmPanel")]
    public Text confirmOrderTypeText;
    public Text confirmPayMethodText;
    public Text confirmTotalText;
    public Transform confirmListContent;
    public GameObject confirmRowPrefab;

    [Header("CompletePanel")]
    public Text successText;
    public Text receiptContentText;

    private readonly List<GameObject> confirmRows = new List<GameObject>();
    private PayMethod currentPayMethod = PayMethod.None;

    private void Start()
    {
        BindButtons();
        ResetPaymentState();
    }

    private void BindButtons()
    {
        AddClick(cardBtn, () => SelectPayMethod(PayMethod.Card));
        AddClick(pointBtn, () => SelectPayMethod(PayMethod.Point));
        AddClick(applePayBtn, () => SelectPayMethod(PayMethod.ApplePay));
        AddClick(samsungPayBtn, () => SelectPayMethod(PayMethod.SamsungPay));
    }

    public void OnEnterPayment()
    {
        ResetPaymentState();
        RefreshPaymentPanel();
    }

    public void ResetPaymentStateExternally()
    {
        ResetPaymentState();
        RefreshPaymentPanel();
    }

    public bool HasSelectedPayMethod()
    {
        return currentPayMethod != PayMethod.None;
    }

    private void ResetPaymentState()
    {
        currentPayMethod = PayMethod.None;

        if (selectedPayMethodText != null)
            selectedPayMethodText.text = "결제수단: 미선택";

        if (paymentGuideText != null)
            paymentGuideText.text = "결제수단을 선택해주세요.";
    }

    private void RefreshPaymentPanel()
    {
        int total = productManager != null ? productManager.GetCartTotal() : 0;

        if (payAmountText != null)
            payAmountText.text = $"결제금액: {total:N0}원";
    }

    private void SelectPayMethod(PayMethod method)
    {
        currentPayMethod = method;

        if (selectedPayMethodText != null)
            selectedPayMethodText.text = $"결제수단: {GetPayMethodText(method)}";

        if (paymentGuideText != null)
            paymentGuideText.text = GetGuideText(method);
    }

    public void BuildConfirmPage()
    {
        ClearConfirmRows();

        if (panelManager != null && confirmOrderTypeText != null)
        {
            string orderTypeText = panelManager.currentOrderType == Script1_PanelManager.OrderType.Pickup ? "픽업" : "배달";
            confirmOrderTypeText.text = $"수령방식: {orderTypeText}";
        }

        if (confirmPayMethodText != null)
            confirmPayMethodText.text = $"결제수단: {GetPayMethodText(currentPayMethod)}";

        if (productManager == null)
            return;

        int total = 0;
        foreach (var item in productManager.cart)
        {
            if (confirmListContent != null && confirmRowPrefab != null)
            {
                var row = Instantiate(confirmRowPrefab, confirmListContent);
                var texts = row.GetComponentsInChildren<Text>();

                SetText(texts, 0, item.productName);
                SetText(texts, 1, item.OptionSummary());
                SetText(texts, 2, $"{item.quantity}개");
                SetText(texts, 3, $"{item.totalPrice:N0}원");

                confirmRows.Add(row);
            }

            total += item.totalPrice;
        }

        if (confirmTotalText != null)
            confirmTotalText.text = $"최종 결제금액: {total:N0}원";
    }

    public void FinalizePayment()
    {
        BuildReceipt();

        if (successText != null)
            successText.text = "결제가 완료되었습니다.";

        panelManager?.ShowComplete();
    }

    private void BuildReceipt()
    {
        if (receiptContentText == null || productManager == null)
            return;

        var sb = new StringBuilder();
        sb.AppendLine("[ Fresh Fruit Kiosk 영수증 ]");
        sb.AppendLine($"일시: {System.DateTime.Now:yyyy-MM-dd HH:mm}");

        if (panelManager != null)
        {
            string orderTypeText = panelManager.currentOrderType == Script1_PanelManager.OrderType.Pickup ? "픽업" : "배달";
            sb.AppendLine($"수령방식: {orderTypeText}");
        }

        sb.AppendLine($"결제수단: {GetPayMethodText(currentPayMethod)}");
        sb.AppendLine("----------------------------------------");

        int total = 0;
        foreach (var item in productManager.cart)
        {
            sb.AppendLine(item.productName);
            sb.AppendLine($" 옵션: {item.OptionSummary()}");
            sb.AppendLine($" 수량: {item.quantity}개 / 금액: {item.totalPrice:N0}원");
            total += item.totalPrice;
        }

        sb.AppendLine("----------------------------------------");
        sb.AppendLine($"합계: {total:N0}원");

        receiptContentText.text = sb.ToString();
    }

    private string GetGuideText(PayMethod method)
    {
        switch (method)
        {
            case PayMethod.Card: return "카드를 넣거나 단말기에 태그해주세요.";
            case PayMethod.Point: return "포인트 결제를 진행합니다.";
            case PayMethod.ApplePay: return "아이폰 또는 애플워치를 단말기에 가까이 대주세요.";
            case PayMethod.SamsungPay: return "휴대폰을 단말기에 가까이 대주세요.";
            default: return "결제수단을 선택해주세요.";
        }
    }

    private string GetPayMethodText(PayMethod method)
    {
        switch (method)
        {
            case PayMethod.Card: return "카드";
            case PayMethod.Point: return "포인트";
            case PayMethod.ApplePay: return "애플페이";
            case PayMethod.SamsungPay: return "삼성페이";
            default: return "미선택";
        }
    }

    private void ClearConfirmRows()
    {
        foreach (var row in confirmRows)
            Destroy(row);

        confirmRows.Clear();
    }

    private void AddClick(Button button, UnityEngine.Events.UnityAction action)
    {
        if (button != null)
            button.onClick.AddListener(action);
    }

    private void SetText(Text[] texts, int index, string value)
    {
        if (texts != null && texts.Length > index && texts[index] != null)
            texts[index].text = value;
    }
}
