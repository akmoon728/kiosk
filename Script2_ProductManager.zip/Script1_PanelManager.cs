using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Panel 전환 전용 매니저
/// Intro -> OrderType -> Product -> Option -> Cart -> Payment -> Confirm -> Complete
/// </summary>
public class Script1_PanelManager : MonoBehaviour
{
    public enum OrderType
    {
        Pickup,
        Delivery
    }

    [Header("메인 패널")]
    public GameObject introPanel;
    public GameObject orderTypePanel;
    public GameObject productPanel;
    public GameObject optionPanel;
    public GameObject cartPanel;
    public GameObject paymentPanel;
    public GameObject confirmPanel;
    public GameObject completePanel;

    [Header("인트로")]
    public Button startIntroBtn;
    public Button introNextBtn;

    [Header("주문 방식")]
    public Button pickupBtn;
    public Button deliveryBtn;
    public Button orderTypeNextBtn;
    public Text orderTypeSelectedText;

    [Header("카테고리 탭")]
    public Button tabFruit;
    public Button tabCupFruit;
    public Button tabGiftFruit;

    [Header("상품 목록 패널")]
    public GameObject gridFruit;
    public GameObject gridCupFruit;
    public GameObject gridGiftFruit;

    [Header("상품/장바구니 이동")]
    public Button productToCartBtn;
    public Button optionBackBtn;
    public Button optionToCartBtn;
    public Button cartBackBtn;
    public Button cartToPaymentBtn;

    [Header("결제/확인 이동")]
    public Button paymentBackBtn;
    public Button paymentToConfirmBtn;
    public Button confirmBackBtn;
    public Button confirmPayBtn;

    [Header("완료")]
    public Button completeNextBtn;
    public Button homeBtn;

    [Header("외부 참조")]
    public Script2_ProductManager productManager;
    public Script3_PaymentManager paymentManager;

    [HideInInspector] public OrderType currentOrderType = OrderType.Pickup;
    [HideInInspector] public int currentTabIndex = 0;

    private static readonly Color ActiveColor = new Color(0.18f, 0.42f, 0.31f);
    private static readonly Color InactiveColor = new Color(0.55f, 0.55f, 0.55f);

    private void Start()
    {
        BindButtons();
        ShowIntro();
        SwitchTab(0);
        RefreshOrderTypeUI();
    }

    private void BindButtons()
    {
        AddClick(startIntroBtn, ShowOrderType);
        AddClick(introNextBtn, ShowOrderType);

        AddClick(pickupBtn, () => SetOrderType(OrderType.Pickup));
        AddClick(deliveryBtn, () => SetOrderType(OrderType.Delivery));
        AddClick(orderTypeNextBtn, ShowProduct);

        AddClick(tabFruit, () => SwitchTab(0));
        AddClick(tabCupFruit, () => SwitchTab(1));
        AddClick(tabGiftFruit, () => SwitchTab(2));

        AddClick(productToCartBtn, ShowCart);
        AddClick(optionBackBtn, ShowProduct);
        AddClick(optionToCartBtn, GoOptionToCart);
        AddClick(cartBackBtn, ShowProduct);
        AddClick(cartToPaymentBtn, GoCartToPayment);

        AddClick(paymentBackBtn, ShowCart);
        AddClick(paymentToConfirmBtn, GoPaymentToConfirm);
        AddClick(confirmBackBtn, ShowPayment);
        AddClick(confirmPayBtn, FinalizePayment);

        AddClick(completeNextBtn, ResetToHome);
        AddClick(homeBtn, ResetToHome);
    }

    public void SetOrderType(OrderType orderType)
    {
        currentOrderType = orderType;
        RefreshOrderTypeUI();
    }

    public void ShowIntro() => ShowOnly(introPanel);
    public void ShowOrderType() => ShowOnly(orderTypePanel);
    public void ShowProduct() => ShowOnly(productPanel);
    public void ShowOption() => ShowOnly(optionPanel);
    public void ShowCart()
    {
        ShowOnly(cartPanel);
        productManager?.RefreshCartPanel();
        productManager?.RefreshCartPage();
    }

    public void ShowPayment()
    {
        ShowOnly(paymentPanel);
        paymentManager?.OnEnterPayment();
    }

    public void ShowConfirm()
    {
        ShowOnly(confirmPanel);
        paymentManager?.BuildConfirmPage();
    }

    public void ShowComplete() => ShowOnly(completePanel);

    public void SwitchTab(int index)
    {
        currentTabIndex = index;

        SetActive(gridFruit, index == 0);
        SetActive(gridCupFruit, index == 1);
        SetActive(gridGiftFruit, index == 2);

        SetButtonTextColor(tabFruit, index == 0);
        SetButtonTextColor(tabCupFruit, index == 1);
        SetButtonTextColor(tabGiftFruit, index == 2);
    }

    public void ResetToHome()
    {
        productManager?.ResetAll();
        paymentManager?.ResetPaymentStateExternally();
        currentOrderType = OrderType.Pickup;
        SwitchTab(0);
        RefreshOrderTypeUI();
        ShowIntro();
    }

    private void GoOptionToCart()
    {
        productManager?.AddCurrentItemToCart();
        ShowCart();
    }

    private void GoCartToPayment()
    {
        if (productManager == null || !productManager.HasCartItems())
            return;

        ShowPayment();
    }

    private void GoPaymentToConfirm()
    {
        if (paymentManager == null || !paymentManager.HasSelectedPayMethod())
            return;

        ShowConfirm();
    }

    private void FinalizePayment()
    {
        paymentManager?.FinalizePayment();
    }

    private void RefreshOrderTypeUI()
    {
        if (orderTypeSelectedText != null)
            orderTypeSelectedText.text = currentOrderType == OrderType.Pickup ? "선택: 픽업" : "선택: 배달";

        SetButtonTextColor(pickupBtn, currentOrderType == OrderType.Pickup);
        SetButtonTextColor(deliveryBtn, currentOrderType == OrderType.Delivery);
    }

    private void ShowOnly(GameObject target)
    {
        SetActive(introPanel, target == introPanel);
        SetActive(orderTypePanel, target == orderTypePanel);
        SetActive(productPanel, target == productPanel);
        SetActive(optionPanel, target == optionPanel);
        SetActive(cartPanel, target == cartPanel);
        SetActive(paymentPanel, target == paymentPanel);
        SetActive(confirmPanel, target == confirmPanel);
        SetActive(completePanel, target == completePanel);
    }

    private void SetButtonTextColor(Button button, bool isActive)
    {
        if (button == null)
            return;

        var label = button.GetComponentInChildren<Text>();
        if (label != null)
            label.color = isActive ? ActiveColor : InactiveColor;
    }

    private void AddClick(Button button, UnityEngine.Events.UnityAction action)
    {
        if (button != null)
            button.onClick.AddListener(action);
    }

    private void SetActive(GameObject target, bool active)
    {
        if (target != null)
            target.SetActive(active);
    }
}
