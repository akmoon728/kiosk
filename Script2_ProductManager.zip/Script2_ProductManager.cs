using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 상품 선택, 옵션 선택, 장바구니 관리를 담당한다.
/// 팝업 없이 OptionPanel과 CartPanel로만 동작한다.
/// </summary>
public class Script2_ProductManager : MonoBehaviour
{
    public enum ProductCategory
    {
        NormalFruit,
        CupFruit,
        GiftFruit
    }

    public enum SizeOption
    {
        Small,
        Medium,
        Large
    }

    public enum SweetnessOption
    {
        Low,
        Medium,
        High
    }

    public enum CuttingOption
    {
        None,
        Half,
        Ready
    }

    [System.Serializable]
    public class ProductData
    {
        public string productName;
        public ProductCategory category;
        public int basePrice;
    }

    [System.Serializable]
    public class CartItem
    {
        public string productName;
        public ProductCategory category;
        public SizeOption size;
        public SweetnessOption sweetness;
        public CuttingOption cutting;
        public int quantity;
        public int unitPrice;
        public int totalPrice;

        public string OptionSummary()
        {
            return $"크기:{ToKorean(size)} / 당도:{ToKorean(sweetness)} / 커팅:{ToKorean(cutting)}";
        }

        private static string ToKorean(SizeOption value)
        {
            switch (value)
            {
                case SizeOption.Small: return "소";
                case SizeOption.Medium: return "중";
                case SizeOption.Large: return "대";
                default: return "중";
            }
        }

        private static string ToKorean(SweetnessOption value)
        {
            switch (value)
            {
                case SweetnessOption.Low: return "낮음";
                case SweetnessOption.Medium: return "보통";
                case SweetnessOption.High: return "높음";
                default: return "보통";
            }
        }

        private static string ToKorean(CuttingOption value)
        {
            switch (value)
            {
                case CuttingOption.None: return "안함";
                case CuttingOption.Half: return "반커팅";
                case CuttingOption.Ready: return "바로먹기";
                default: return "안함";
            }
        }
    }

    [Header("외부 참조")]
    public Script1_PanelManager panelManager;

    [Header("OptionPanel 텍스트")]
    public Text optionTitleText;
    public Text optionTotalPriceText;
    public Text quantityText;

    [Header("OptionPanel 버튼")]
    public Button minusBtn;
    public Button plusBtn;
    public Button sizeSmallBtn;
    public Button sizeMediumBtn;
    public Button sizeLargeBtn;
    public Button sweetLowBtn;
    public Button sweetMediumBtn;
    public Button sweetHighBtn;
    public Button cutNoneBtn;
    public Button cutHalfBtn;
    public Button cutReadyBtn;

    [Header("옵션 그룹")]
    public GameObject sizeGroup;
    public GameObject sweetGroup;
    public GameObject cutGroup;

    [Header("상품 버튼")]
    public Button[] normalFruitButtons;
    public Button[] cupFruitButtons;
    public Button[] giftFruitButtons;

    [Header("장바구니 요약(ProductPanel)")]
    public Text cartCountText;
    public Text cartTotalText;
    public Button goCartBtn;

    [Header("CartPanel")]
    public Transform cartListContent;
    public GameObject cartRowPrefab;
    public Text cartPageTotalText;
    public Text cartPageCountText;

    [HideInInspector] public readonly List<CartItem> cart = new List<CartItem>();

    private readonly List<GameObject> cartRows = new List<GameObject>();

    private readonly ProductData[] normalFruitProducts =
    {
        new ProductData { productName = "사과", category = ProductCategory.NormalFruit, basePrice = 5000 },
        new ProductData { productName = "배", category = ProductCategory.NormalFruit, basePrice = 6500 },
        new ProductData { productName = "귤", category = ProductCategory.NormalFruit, basePrice = 4500 },
        new ProductData { productName = "키위", category = ProductCategory.NormalFruit, basePrice = 5500 },
        new ProductData { productName = "수박", category = ProductCategory.NormalFruit, basePrice = 12000 }
    };

    private readonly ProductData[] cupFruitProducts =
    {
        new ProductData { productName = "사과 컵과일", category = ProductCategory.CupFruit, basePrice = 5500 },
        new ProductData { productName = "배 컵과일", category = ProductCategory.CupFruit, basePrice = 7000 },
        new ProductData { productName = "귤 컵과일", category = ProductCategory.CupFruit, basePrice = 5000 },
        new ProductData { productName = "키위 컵과일", category = ProductCategory.CupFruit, basePrice = 6500 },
        new ProductData { productName = "수박 컵과일", category = ProductCategory.CupFruit, basePrice = 8000 }
    };

    private readonly ProductData[] giftFruitProducts =
    {
        new ProductData { productName = "사과 선물용", category = ProductCategory.GiftFruit, basePrice = 28000 },
        new ProductData { productName = "배 선물용", category = ProductCategory.GiftFruit, basePrice = 32000 },
        new ProductData { productName = "귤 선물용", category = ProductCategory.GiftFruit, basePrice = 24000 },
        new ProductData { productName = "키위 선물용", category = ProductCategory.GiftFruit, basePrice = 30000 },
        new ProductData { productName = "수박 선물용", category = ProductCategory.GiftFruit, basePrice = 35000 }
    };

    private ProductData currentProduct;
    private int currentQuantity = 1;
    private SizeOption currentSize = SizeOption.Medium;
    private SweetnessOption currentSweetness = SweetnessOption.Medium;
    private CuttingOption currentCutting = CuttingOption.None;

    private void Start()
    {
        BindButtons();
        RefreshCartPanel();
        RefreshCartPage();
        ClearOptionTexts();
    }

    private void BindButtons()
    {
        AddClick(minusBtn, () => ChangeQuantity(-1));
        AddClick(plusBtn, () => ChangeQuantity(1));

        AddClick(sizeSmallBtn, () => SetSize(SizeOption.Small));
        AddClick(sizeMediumBtn, () => SetSize(SizeOption.Medium));
        AddClick(sizeLargeBtn, () => SetSize(SizeOption.Large));

        AddClick(sweetLowBtn, () => SetSweetness(SweetnessOption.Low));
        AddClick(sweetMediumBtn, () => SetSweetness(SweetnessOption.Medium));
        AddClick(sweetHighBtn, () => SetSweetness(SweetnessOption.High));

        AddClick(cutNoneBtn, () => SetCutting(CuttingOption.None));
        AddClick(cutHalfBtn, () => SetCutting(CuttingOption.Half));
        AddClick(cutReadyBtn, () => SetCutting(CuttingOption.Ready));

        AddClick(goCartBtn, () => panelManager?.ShowCart());

        BindProductButtons(normalFruitButtons, normalFruitProducts);
        BindProductButtons(cupFruitButtons, cupFruitProducts);
        BindProductButtons(giftFruitButtons, giftFruitProducts);
    }

    private void BindProductButtons(Button[] buttons, ProductData[] products)
    {
        if (buttons == null || products == null)
            return;

        int count = Mathf.Min(buttons.Length, products.Length);
        for (int i = 0; i < count; i++)
        {
            int index = i;
            AddClick(buttons[index], () => SelectProduct(products[index]));
        }
    }

    public void SelectProduct(ProductData product)
    {
        currentProduct = product;
        currentQuantity = 1;
        currentSize = SizeOption.Medium;
        currentSweetness = SweetnessOption.Medium;
        currentCutting = product.category == ProductCategory.CupFruit ? CuttingOption.Ready : CuttingOption.None;

        SetActive(sizeGroup, true);
        SetActive(sweetGroup, true);
        SetActive(cutGroup, true);

        RefreshOptionUI();
        panelManager?.ShowOption();
    }

    private void ChangeQuantity(int delta)
    {
        currentQuantity = Mathf.Max(1, currentQuantity + delta);
        RefreshOptionUI();
    }

    private void SetSize(SizeOption value)
    {
        currentSize = value;
        RefreshOptionUI();
    }

    private void SetSweetness(SweetnessOption value)
    {
        currentSweetness = value;
        RefreshOptionUI();
    }

    private void SetCutting(CuttingOption value)
    {
        currentCutting = value;
        RefreshOptionUI();
    }

    private void RefreshOptionUI()
    {
        if (currentProduct == null)
            return;

        int totalPrice = CalculateUnitPrice() * currentQuantity;

        if (optionTitleText != null) optionTitleText.text = currentProduct.productName;
        if (optionTotalPriceText != null) optionTotalPriceText.text = $"합계: {totalPrice:N0}원";
        if (quantityText != null) quantityText.text = currentQuantity.ToString(); ;
    }

    private int CalculateUnitPrice()
    {
        if (currentProduct == null)
            return 0;

        int price = currentProduct.basePrice;

        switch (currentSize)
        {
            case SizeOption.Medium: price += 1000; break;
            case SizeOption.Large: price += 2500; break;
        }

        if (currentSweetness == SweetnessOption.High)
            price += 1000;

        if (currentCutting == CuttingOption.Half)
            price += 500;
        else if (currentCutting == CuttingOption.Ready)
            price += 1000;

        if (currentProduct.category == ProductCategory.GiftFruit)
            price += 3000;

        return price;
    }

    
    public void AddCurrentItemToCart()
    {
        if (currentProduct == null)
            return;

        int unitPrice = CalculateUnitPrice();

        cart.Add(new CartItem
        {
            productName = currentProduct.productName,
            category = currentProduct.category,
            size = currentSize,
            sweetness = currentSweetness,
            cutting = currentCutting,
            quantity = currentQuantity,
            unitPrice = unitPrice,
            totalPrice = unitPrice * currentQuantity
        });

        RefreshCartPanel();
        RefreshCartPage();
    }

    public void RefreshCartPanel()
    {
        int totalCount = cart.Sum(item => item.quantity);
        int totalPrice = cart.Sum(item => item.totalPrice);

        if (cartCountText != null) cartCountText.text = $"{totalCount}개 담김";
        if (cartTotalText != null) cartTotalText.text = $"합계: {totalPrice:N0}원";
        if (goCartBtn != null) goCartBtn.interactable = cart.Count > 0;
    }

    public void RefreshCartPage()
    {
        ClearCartRows();

        int totalCount = 0;
        int totalPrice = 0;

        if (cartListContent != null && cartRowPrefab != null)
        {
            foreach (var item in cart)
            {
                var row = Instantiate(cartRowPrefab, cartListContent);
                var texts = row.GetComponentsInChildren<Text>();

                SetText(texts, 0, item.productName);
                SetText(texts, 1, item.OptionSummary());
                SetText(texts, 2, $"{item.quantity}개");
                SetText(texts, 3, $"{item.totalPrice:N0}원");

                cartRows.Add(row);
                totalCount += item.quantity;
                totalPrice += item.totalPrice;
            }
        }
        else
        {
            totalCount = cart.Sum(item => item.quantity);
            totalPrice = cart.Sum(item => item.totalPrice);
        }

        if (cartPageCountText != null) cartPageCountText.text = $"총 수량: {totalCount}개";
        if (cartPageTotalText != null) cartPageTotalText.text = $"총 결제금액: {totalPrice:N0}원";
    }

    public bool HasCartItems()
    {
        return cart.Count > 0;
    }

    public int GetCartTotal()
    {
        return cart.Sum(item => item.totalPrice);
    }

    public void ClearCart()
    {
        cart.Clear();
        RefreshCartPanel();
        RefreshCartPage();
    }

    public void ResetAll()
    {
        currentProduct = null;
        currentQuantity = 1;
        currentSize = SizeOption.Medium;
        currentSweetness = SweetnessOption.Medium;
        currentCutting = CuttingOption.None;
        ClearCart();
        ClearOptionTexts();
    }

    private void ClearOptionTexts()
    {
        if (optionTitleText != null) optionTitleText.text = "상품을 선택하세요";
        if (optionTotalPriceText != null) optionTotalPriceText.text = "합계: 0원";
        if (quantityText != null) quantityText.text = "1";
    }

    
    private void AddClick(Button button, UnityEngine.Events.UnityAction action)
    {
        if (button != null)
            button.onClick.AddListener(action);
    }

    private void SetActive(GameObject target, bool active)
    {
        if (target != null)
            target.SetActive(active);
    }

    private void ClearCartRows()
    {
        foreach (var row in cartRows)
            Destroy(row);

        cartRows.Clear();
    }

    private void SetText(Text[] texts, int index, string value)
    {
        if (texts != null && texts.Length > index && texts[index] != null)
            texts[index].text = value;
    }
}
