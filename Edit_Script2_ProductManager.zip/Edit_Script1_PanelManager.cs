using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 과일 키오스크 패널 전환 전용 매니저
/// 흐름: Intro -> Start -> Product -> Option -> Cart -> Payment -> Confirm -> Complete
/// </summary>
public class Script1_PanelManager : MonoBehaviour
{
    [Header("메인 패널")]
    public GameObject introPanel;
    public GameObject startPanel;
    public GameObject productPanel;
    public GameObject optionPanel;
    public GameObject cartPanel;
    public GameObject paymentPanel;
    public GameObject confirmPanel;
    public GameObject completePanel;

    [Header("인트로")]
    public Button startIntroBtn;
    public Button introNextBtn;

    [Header("주문 방식")]
    public Button pickupBtn;
    public Button deliveryBtn;
    public Button startNextBtn;

    [Header("카테고리 탭")]
    public Button tabFruit;
    public Button tabCup;
    public Button tabGift;

    [Header("상품 목록 영역")]
    public GameObject gridFruit;
    public GameObject gridCup;
    public GameObject gridGift;

    [Header("이동 버튼")]
    public Button goProductBtn;
    public Button backToProductBtn;
    public Button goCartBtn;
    public Button cartBackBtn;
    public Button goPaymentBtn;
    public Button paymentBackBtn;
    public Button goConfirmBtn;
    public Button confirmBackBtn;
    public Button homeBtn;
    public Button completeNextBtn;

    [Header("외부 참조")]
    public Script2_ProductManager productManager;
    public Script3_PaymentManager paymentManager;

    [HideInInspector] public string orderType = "Pickup";

    private void Start()
    {
        BindButtons();
        ShowIntro();
        SwitchTab(0);
    }

    private void BindButtons()
    {
        AddClick(startIntroBtn, ShowStart);
        AddClick(introNextBtn, ShowStart);

        AddClick(pickupBtn, () => orderType = "Pickup");
        AddClick(deliveryBtn, () => orderType = "Delivery");
        AddClick(startNextBtn, ShowProduct);

        AddClick(tabFruit, () => SwitchTab(0));
        AddClick(tabCup, () => SwitchTab(1));
        AddClick(tabGift, () => SwitchTab(2));

        AddClick(goProductBtn, ShowProduct);
        AddClick(backToProductBtn, ShowProduct);
        AddClick(goCartBtn, ShowCart);
        AddClick(cartBackBtn, ShowProduct);

        AddClick(goPaymentBtn, ShowPayment);
        AddClick(paymentBackBtn, ShowCart);

        AddClick(goConfirmBtn, ShowConfirm);
        AddClick(confirmBackBtn, ShowPayment);

        AddClick(homeBtn, ResetToHome);
        AddClick(completeNextBtn, ResetToHome);
    }

    public void ShowIntro()
    {
        ShowOnly(introPanel);
    }

    public void ShowStart()
    {
        ShowOnly(startPanel);
    }

    public void ShowProduct()
    {
        ShowOnly(productPanel);
    }

    public void ShowOption()
    {
        ShowOnly(optionPanel);
    }

    public void ShowCart()
    {
        ShowOnly(cartPanel);
        productManager?.RefreshCartPage();
    }

    public void ShowPayment()
    {
        ShowOnly(paymentPanel);
        paymentManager?.OnEnterPayment();
    }

    public void ShowConfirm()
    {
        ShowOnly(confirmPanel);
        paymentManager?.RefreshConfirmPanel();
    }

    public void ShowComplete()
    {
        ShowOnly(completePanel);
    }

    private void ShowOnly(GameObject target)
    {
        SetActive(introPanel, target == introPanel);
        SetActive(startPanel, target == startPanel);
        SetActive(productPanel, target == productPanel);
        SetActive(optionPanel, target == optionPanel);
        SetActive(cartPanel, target == cartPanel);
        SetActive(paymentPanel, target == paymentPanel);
        SetActive(confirmPanel, target == confirmPanel);
        SetActive(completePanel, target == completePanel);
    }

    public void SwitchTab(int index)
    {
        SetActive(gridFruit, index == 0);
        SetActive(gridCup, index == 1);
        SetActive(gridGift, index == 2);
    }

    public void ResetToHome()
    {
        orderType = "Pickup";
        productManager?.ResetAll();
        ShowIntro();
        SwitchTab(0);
    }

    private void AddClick(Button button, UnityEngine.Events.UnityAction action)
    {
        if (button != null)
            button.onClick.AddListener(action);
    }

    private void SetActive(GameObject target, bool active)
    {
        if (target != null)
            target.SetActive(active);
    }
}
